#pragma once

#include "Information.h"

namespace OOPSA02 {

    using namespace System;
    using namespace System::Windows::Forms;

    public ref class SearchByTimeAndDay : public System::Windows::Forms::Form {
    private:
        System::Windows::Forms::Form^ DB;

    public:
        SearchByTimeAndDay(void) {
            InitializeComponent();
        }
        SearchByTimeAndDay(System::Windows::Forms::Form^ frm)
        {
            InitializeComponent();
            DB = frm;
        }

    protected:
        ~SearchByTimeAndDay() {
            if (components) {
                delete components;
            }
        }

    private:
        System::Windows::Forms::ComboBox^ cbDay;
        System::Windows::Forms::ComboBox^ cbTime;
        System::Windows::Forms::Button^ btnSearch;
        System::Windows::Forms::Button^ btnGoBack;
        System::Windows::Forms::DataGridView^ dataGridView1;
        System::Windows::Forms::Label^ label1;
        System::ComponentModel::Container^ components;

        void InitializeComponent(void) {
            this->cbDay = (gcnew System::Windows::Forms::ComboBox());
            this->cbTime = (gcnew System::Windows::Forms::ComboBox());
            this->btnSearch = (gcnew System::Windows::Forms::Button());
            this->btnGoBack = (gcnew System::Windows::Forms::Button());
            this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
            this->label1 = (gcnew System::Windows::Forms::Label());
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
            this->SuspendLayout();
            // 
            // cbDay
            // 
            this->cbDay->FormattingEnabled = true;
            this->cbDay->Items->AddRange(gcnew cli::array< System::Object^  >(7) {
                L"Monday", L"Tuesday", L"Wednesday", L"Thursday", L"Friday",
                    L"Saturday", L"Sunday"
            });
            this->cbDay->Location = System::Drawing::Point(103, 94);
            this->cbDay->Name = L"cbDay";
            this->cbDay->Size = System::Drawing::Size(277, 21);
            this->cbDay->TabIndex = 2;
            // 
            // cbTime
            // 
            this->cbTime->FormattingEnabled = true;
            this->cbTime->Items->AddRange(gcnew cli::array< System::Object^  >(24) {
                L"00:00", L"01:00", L"02:00", L"03:00", L"04:00",
                    L"05:00", L"06:00", L"07:00", L"08:00", L"09:00", L"10:00", L"11:00", L"12:00", L"13:00", L"14:00", L"15:00", L"16:00", L"17:00",
                    L"18:00", L"19:00", L"20:00", L"21:00", L"22:00", L"23:00"
            });
            this->cbTime->Location = System::Drawing::Point(103, 159);
            this->cbTime->Name = L"cbTime";
            this->cbTime->Size = System::Drawing::Size(277, 21);
            this->cbTime->TabIndex = 3;
            // 
            // btnSearch
            // 
            this->btnSearch->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
                static_cast<System::Byte>(0)));
            this->btnSearch->Location = System::Drawing::Point(103, 218);
            this->btnSearch->Name = L"btnSearch";
            this->btnSearch->Size = System::Drawing::Size(121, 37);
            this->btnSearch->TabIndex = 6;
            this->btnSearch->Text = L"Search";
            this->btnSearch->UseVisualStyleBackColor = true;
            this->btnSearch->Click += gcnew System::EventHandler(this, &SearchByTimeAndDay::btnSearch_Click);
            // 
            // btnGoBack
            // 
            this->btnGoBack->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
                static_cast<System::Byte>(0)));
            this->btnGoBack->Location = System::Drawing::Point(251, 218);
            this->btnGoBack->Name = L"btnGoBack";
            this->btnGoBack->Size = System::Drawing::Size(129, 37);
            this->btnGoBack->TabIndex = 8;
            this->btnGoBack->Text = L"Go Back";
            this->btnGoBack->UseVisualStyleBackColor = true;
            this->btnGoBack->Click += gcnew System::EventHandler(this, &SearchByTimeAndDay::btnGoBack_Click);
            // 
            // dataGridView1
            // 
            this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
            this->dataGridView1->Location = System::Drawing::Point(12, 281);
            this->dataGridView1->Name = L"dataGridView1";
            this->dataGridView1->Size = System::Drawing::Size(483, 150);
            this->dataGridView1->TabIndex = 9;
            this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &SearchByTimeAndDay::dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this->label1->AutoSize = true;
            this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
                static_cast<System::Byte>(0)));
            this->label1->Location = System::Drawing::Point(98, 33);
            this->label1->Name = L"label1";
            this->label1->Size = System::Drawing::Size(312, 25);
            this->label1->TabIndex = 10;
            this->label1->Text = L"SEARCH BY TIME AND DAY";
            // 
            // SearchByTimeAndDay
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(530, 468);
            this->Controls->Add(this->label1);
            this->Controls->Add(this->dataGridView1);
            this->Controls->Add(this->btnGoBack);
            this->Controls->Add(this->btnSearch);
            this->Controls->Add(this->cbTime);
            this->Controls->Add(this->cbDay);
            this->Name = L"SearchByTimeAndDay";
            this->Text = L"SearchByTimeAndDay";
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
            this->ResumeLayout(false);
            this->PerformLayout();

        }

        void btnSearch_Click(System::Object^ sender, System::EventArgs^ e) {
            // Validate DataManager instance
            if (DataManager::Instance == nullptr) {
                MessageBox::Show("DataManager instance is not initialized.");
                return;
            }

            // Clear existing rows in the data grid view
            dataGridView1->Rows->Clear();

            // Retrieve selected day and time from combo boxes
            String^ day = cbDay->Text;
            String^ time = cbTime->Text;

            // Validate selected day and time
            if (String::IsNullOrEmpty(day) || String::IsNullOrEmpty(time)) {
                MessageBox::Show("Please select both day and time.");
                return;
            }

            // Add columns to the data grid view
            dataGridView1->Columns->Clear();
            dataGridView1->Columns->Add("CourseName", "Course Name");
            dataGridView1->Columns->Add("Time", "Time");
            dataGridView1->Columns->Add("Teacher", "Teacher");
            dataGridView1->Columns->Add("Room", "Room");

            // Search for courses matching the selected day and time
            for each (Course ^ course in DataManager::Instance->courses) {
                // Extract the day and time from the course's time string
                String^ courseTime = course->time;
                array<String^>^ splitTime = courseTime->Split(' ');
                String^ courseDay = splitTime[1];
                String^ courseHour = splitTime[0];

                // Check if the course's day and time match the selected day and time
                if (courseDay->Equals(day) && courseHour->Equals(time)) {
                    DataGridViewRow^ row = gcnew DataGridViewRow();
                    row->CreateCells(dataGridView1);

                    // Assign course details to the row
                    row->Cells[0]->Value = course->name;
                    row->Cells[1]->Value = courseTime; // Display the full time string
                    row->Cells[2]->Value = course->teacher->name;
                    row->Cells[3]->Value = course->room->number;

                    // Add the row to the DataGridView
                    dataGridView1->Rows->Add(row);
                }
            }
        }

        void btnGoBack_Click(System::Object^ sender, System::EventArgs^ e) {
           
            this->DB->Show();
            this->Close();
        }
    private: System::Void dataGridView1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
    }
};
}
