#pragma once

#include "RegisterForm.h"
#include "Login.h"

namespace OOPSA02 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:









	private: System::Windows::Forms::Label^ label4;

	private: System::Windows::Forms::Button^ btnMainRegister;
	private: System::Windows::Forms::Button^ btnMainExit;






	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->btnMainRegister = (gcnew System::Windows::Forms::Button());
			this->btnMainExit = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(36, 52);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(601, 37);
			this->label4->TabIndex = 6;
			this->label4->Text = L"TIMETABLE MANAGEMENT SYSTEM";
			// 
			// btnMainRegister
			// 
			this->btnMainRegister->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnMainRegister->Location = System::Drawing::Point(190, 184);
			this->btnMainRegister->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->btnMainRegister->Name = L"btnMainRegister";
			this->btnMainRegister->Size = System::Drawing::Size(264, 83);
			this->btnMainRegister->TabIndex = 8;
			this->btnMainRegister->Text = L"REGISTER";
			this->btnMainRegister->UseVisualStyleBackColor = true;
			this->btnMainRegister->Click += gcnew System::EventHandler(this, &MyForm::btnMainRegister_Click);
			// 
			// btnMainExit
			// 
			this->btnMainExit->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnMainExit->Location = System::Drawing::Point(190, 311);
			this->btnMainExit->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->btnMainExit->Name = L"btnMainExit";
			this->btnMainExit->Size = System::Drawing::Size(264, 64);
			this->btnMainExit->TabIndex = 9;
			this->btnMainExit->Text = L"EXIT";
			this->btnMainExit->UseVisualStyleBackColor = true;
			this->btnMainExit->Click += gcnew System::EventHandler(this, &MyForm::btnMainExit_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(652, 542);
			this->Controls->Add(this->btnMainExit);
			this->Controls->Add(this->btnMainRegister);
			this->Controls->Add(this->label4);
			this->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	
	
private: System::Void btnMainRegister_Click(System::Object^ sender, System::EventArgs^ e) {

	RegisterForm^ RG = gcnew RegisterForm();
	this->Hide();
	RG->Show();
	

	
	
}

private: System::Void btnMainExit_Click(System::Object^ sender, System::EventArgs^ e) {
	Application::Exit();
}
};
}
