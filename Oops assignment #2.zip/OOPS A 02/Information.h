#pragma once
#using <mscorlib.dll>
using namespace System;

public ref class Student
{
public:
    String^ name;
    String^ grade;
    String^ id;

    Student(String^ n, String^ g, String^ i) : name(n), grade(g), id(i) {}
};

public ref class Teacher
{
public:
    String^ name;
    String^ subject;

    Teacher(String^ n, String^ s) : name(n), subject(s) {}
};

public ref class Room
{
public:
    String^ number;
    int capacity;

    Room(String^ n, int c) : number(n), capacity(c) {}
};

public ref class Course
{
public:
    String^ code;
    String^ name;
    Teacher^ teacher;
    String^ time;
    Room^ room;

    Course(String^ cd, String^ n, Teacher^ t, String^ tm, Room^ r) : code(cd), name(n), teacher(t), time(tm), room(r) {}
};

public ref class DataManager
{
private:
    static DataManager^ instance = gcnew DataManager();

public:
    array<Student^>^ students;
    array<Teacher^>^ teachers;
    array<Room^>^ rooms;
    array<Course^>^ courses;

    static property DataManager^ Instance
    {
        DataManager^ get() { return instance; }
    }

    DataManager()
    {
        InitializeData();
    }

private:
    void InitializeData()
    {
        students = gcnew array<Student^>
        {
            gcnew Student("Alice", "A", "001"),
                gcnew Student("Bob", "A", "002"),
                gcnew Student("Charlie", "A", "003"),
                gcnew Student("David", "A", "004"),
                gcnew Student("Eve", "B", "005"),
                gcnew Student("Frank", "B", "006"),
                gcnew Student("Grace", "B", "007"),
                gcnew Student("Henry", "C", "008"),
                gcnew Student("Ivy", "C", "009"),
                gcnew Student("Jack", "C", "010")
        };

        teachers = gcnew array<Teacher^>
        {
            gcnew Teacher("Mr. Smith", "Mathematics"),
                gcnew Teacher("Mrs. Johnson", "Physics"),
                gcnew Teacher("Mr. Williams", "Chemistry"),
                gcnew Teacher("Mrs. Brown", "Biology"),
                gcnew Teacher("Mr. Jones", "English")
        };

        rooms = gcnew array<Room^>
        {
            gcnew Room("101", 30),
                gcnew Room("102", 25),
                gcnew Room("103", 20)
        };

        courses = gcnew array<Course^>
        {
            gcnew Course("MATH101", "Calculus", teachers[0], "09:00 Monday", rooms[0]),
                gcnew Course("PHYS101", "Physics", teachers[1], "11:00 Monday", rooms[1]),
                gcnew Course("CHEM101", "Chemistry", teachers[2], "13:00 Monday", rooms[2]),
                gcnew Course("BIO101", "Biology", teachers[3], "09:00 Wednesday", rooms[0]),
                gcnew Course("ENG101", "English", teachers[4], "11:00 Wednesday", rooms[1]),
                gcnew Course("MATH102", "Algebra", teachers[0], "13:00 Wednesday", rooms[2])
        };
    }
};
