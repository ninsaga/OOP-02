#pragma once
#include <msclr/marshal.h>
#include <fstream>
#include"string"
#include "Dashboard.h"



namespace OOPSA02 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	
	/// <summary>
	/// Summary for Login
	/// </summary>
	public ref class Login : public System::Windows::Forms::Form
	{
	public:
		Login(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Login()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Button^ btnLogin;
	private: System::Windows::Forms::Button^ btnLoginCancel;


	private: System::Windows::Forms::TextBox^ LoginUsername;
	private: System::Windows::Forms::TextBox^ LoginPassword;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btnLogin = (gcnew System::Windows::Forms::Button());
			this->btnLoginCancel = (gcnew System::Windows::Forms::Button());
			this->LoginUsername = (gcnew System::Windows::Forms::TextBox());
			this->LoginPassword = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(182, 31);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(122, 37);
			this->label1->TabIndex = 0;
			this->label1->Text = L"LOGIN";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 114);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(139, 25);
			this->label2->TabIndex = 1;
			this->label2->Text = L"USERNAME";
			this->label2->Click += gcnew System::EventHandler(this, &Login::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(12, 168);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(142, 25);
			this->label3->TabIndex = 2;
			this->label3->Text = L"PASSWORD";
			// 
			// btnLogin
			// 
			this->btnLogin->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnLogin->Location = System::Drawing::Point(123, 238);
			this->btnLogin->Name = L"btnLogin";
			this->btnLogin->Size = System::Drawing::Size(94, 36);
			this->btnLogin->TabIndex = 3;
			this->btnLogin->Text = L"LOGIN";
			this->btnLogin->UseVisualStyleBackColor = true;
			this->btnLogin->Click += gcnew System::EventHandler(this, &Login::btnLogin_Click);
			// 
			// btnLoginCancel
			// 
			this->btnLoginCancel->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnLoginCancel->Location = System::Drawing::Point(233, 238);
			this->btnLoginCancel->Name = L"btnLoginCancel";
			this->btnLoginCancel->Size = System::Drawing::Size(120, 36);
			this->btnLoginCancel->TabIndex = 4;
			this->btnLoginCancel->Text = L"CANCEL";
			this->btnLoginCancel->UseVisualStyleBackColor = true;
			// 
			// LoginUsername
			// 
			this->LoginUsername->Location = System::Drawing::Point(154, 114);
			this->LoginUsername->Multiline = true;
			this->LoginUsername->Name = L"LoginUsername";
			this->LoginUsername->Size = System::Drawing::Size(196, 26);
			this->LoginUsername->TabIndex = 5;
			this->LoginUsername->TextChanged += gcnew System::EventHandler(this, &Login::LoginUsername_TextChanged);
			// 
			// LoginPassword
			// 
			this->LoginPassword->Location = System::Drawing::Point(154, 167);
			this->LoginPassword->Multiline = true;
			this->LoginPassword->Name = L"LoginPassword";
			this->LoginPassword->Size = System::Drawing::Size(199, 26);
			this->LoginPassword->TabIndex = 6;
			// 
			// Login
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(426, 339);
			this->Controls->Add(this->LoginPassword);
			this->Controls->Add(this->LoginUsername);
			this->Controls->Add(this->btnLoginCancel);
			this->Controls->Add(this->btnLogin);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Login";
			this->Text = L"Login";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
private: System::Void LoginUsername_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
	   public :
		   bool IsLoginValid(String^ username, String^ password) {
			   
			   std::ifstream file("UserData.txt");

			   
			   if (!file) {
				   MessageBox::Show("Error opening file!");
				   return false;
			   }

			   
			   std::string line;
			   while (std::getline(file, line)) {
				   
				   std::string delimiter = " ";
				   size_t pos = line.find(delimiter);
				   std::string user = line.substr(0, pos);
				   std::string pass = line.substr(pos + delimiter.length());

				   
				   String^ sysUsername = gcnew String(user.c_str());
				   String^ sysPassword = gcnew String(pass.c_str());

				   
				   if (sysUsername == username && sysPassword == password) {
					   file.close();
					   return true;
				   }
			   }

			   
			   file.close();
			   return false;
		   }
private: System::Void btnLogin_Click(System::Object^ sender, System::EventArgs^ e) {

	
	String^ username = LoginUsername->Text;
	String^ password = LoginPassword->Text;

	
	if (IsLoginValid(username, password)) {
		MessageBox::Show("Login successful!");
		Dashboard^ DB = gcnew Dashboard();
		DB->Show();
		this->Hide();
		
	}
	else {
		MessageBox::Show("Invalid username or password!");
	}
}
};
}
