#pragma once

#include "Information.h"
#include <fstream>
#include <iostream>


namespace OOPSA02 {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class AddCourseForm : public System::Windows::Forms::Form
    {
    private:
        System::ComponentModel::Container^ components;

    private:
        System::Windows::Forms::Form^ DB;

    public:
        AddCourseForm(void)
        {
            InitializeComponent();
        }

        AddCourseForm(System::Windows::Forms::Form^ frm)
        {
            InitializeComponent();
            DB = frm;
        }

    protected:
        ~AddCourseForm()
        {
            if (components != nullptr)
            {
                delete components;
            }
        }

    private:
        System::Windows::Forms::Label^ label1;
        System::Windows::Forms::TextBox^ txtCode;
        System::Windows::Forms::TextBox^ txtName;
        System::Windows::Forms::Label^ label2;
        System::Windows::Forms::Label^ label3;
        System::Windows::Forms::ComboBox^ cbTeacher;
        System::Windows::Forms::Label^ label4;
        System::Windows::Forms::ComboBox^ cbRoom;
        System::Windows::Forms::Button^ btnAdd;
        System::Windows::Forms::Button^ btnCancel;

        System::Windows::Forms::Label^ label5;
        System::Windows::Forms::ComboBox^ cbDay;
        System::Windows::Forms::ComboBox^ cbTime;
        System::Windows::Forms::Label^ label6;
        System::Windows::Forms::Label^ label7;

#pragma region Windows Form Designer generated code
        void InitializeComponent(void)
        {
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->txtCode = (gcnew System::Windows::Forms::TextBox());
            this->txtName = (gcnew System::Windows::Forms::TextBox());
            this->label2 = (gcnew System::Windows::Forms::Label());
            this->label3 = (gcnew System::Windows::Forms::Label());
            this->cbTeacher = (gcnew System::Windows::Forms::ComboBox());
            this->label4 = (gcnew System::Windows::Forms::Label());
            this->cbRoom = (gcnew System::Windows::Forms::ComboBox());
            this->btnAdd = (gcnew System::Windows::Forms::Button());
            this->btnCancel = (gcnew System::Windows::Forms::Button());
            this->label5 = (gcnew System::Windows::Forms::Label());
            this->cbDay = (gcnew System::Windows::Forms::ComboBox());
            this->cbTime = (gcnew System::Windows::Forms::ComboBox());
            this->label6 = (gcnew System::Windows::Forms::Label());
            this->label7 = (gcnew System::Windows::Forms::Label());
            this->SuspendLayout();
            // 
            // label1
            // 
            this->label1->AutoSize = true;
            this->label1->Location = System::Drawing::Point(219, 111);
            this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
            this->label1->Name = L"label1";
            this->label1->Size = System::Drawing::Size(51, 20);
            this->label1->TabIndex = 0;
            this->label1->Text = L"Code:";
            // 
            // txtCode
            // 
            this->txtCode->Location = System::Drawing::Point(309, 106);
            this->txtCode->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->txtCode->Name = L"txtCode";
            this->txtCode->Size = System::Drawing::Size(242, 26);
            this->txtCode->TabIndex = 1;
            this->txtCode->TextChanged += gcnew System::EventHandler(this, &AddCourseForm::txtCode_TextChanged);
            // 
            // txtName
            // 
            this->txtName->Location = System::Drawing::Point(309, 146);
            this->txtName->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->txtName->Name = L"txtName";
            this->txtName->Size = System::Drawing::Size(242, 26);
            this->txtName->TabIndex = 2;
            this->txtName->TextChanged += gcnew System::EventHandler(this, &AddCourseForm::txtName_TextChanged);
            // 
            // label2
            // 
            this->label2->AutoSize = true;
            this->label2->Location = System::Drawing::Point(219, 151);
            this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
            this->label2->Name = L"label2";
            this->label2->Size = System::Drawing::Size(55, 20);
            this->label2->TabIndex = 3;
            this->label2->Text = L"Name:";
            // 
            // label3
            // 
            this->label3->AutoSize = true;
            this->label3->Location = System::Drawing::Point(219, 191);
            this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
            this->label3->Name = L"label3";
            this->label3->Size = System::Drawing::Size(71, 20);
            this->label3->TabIndex = 4;
            this->label3->Text = L"Teacher:";
            // 
            // cbTeacher
            // 
            this->cbTeacher->FormattingEnabled = true;
            this->cbTeacher->Location = System::Drawing::Point(309, 186);
            this->cbTeacher->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->cbTeacher->Name = L"cbTeacher";
            this->cbTeacher->Size = System::Drawing::Size(242, 28);
            this->cbTeacher->TabIndex = 5;
            this->cbTeacher->SelectedIndexChanged += gcnew System::EventHandler(this, &AddCourseForm::cbTeacher_SelectedIndexChanged);
            // 
            // label4
            // 
            this->label4->AutoSize = true;
            this->label4->Location = System::Drawing::Point(219, 232);
            this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
            this->label4->Name = L"label4";
            this->label4->Size = System::Drawing::Size(56, 20);
            this->label4->TabIndex = 6;
            this->label4->Text = L"Room:";
            // 
            // cbRoom
            // 
            this->cbRoom->FormattingEnabled = true;
            this->cbRoom->Location = System::Drawing::Point(309, 228);
            this->cbRoom->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->cbRoom->Name = L"cbRoom";
            this->cbRoom->Size = System::Drawing::Size(242, 28);
            this->cbRoom->TabIndex = 7;
            this->cbRoom->SelectedIndexChanged += gcnew System::EventHandler(this, &AddCourseForm::cbRoom_SelectedIndexChanged);
            // 
            // btnAdd
            // 
            this->btnAdd->Location = System::Drawing::Point(309, 363);
            this->btnAdd->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->btnAdd->Name = L"btnAdd";
            this->btnAdd->Size = System::Drawing::Size(112, 35);
            this->btnAdd->TabIndex = 8;
            this->btnAdd->Text = L"Add";
            this->btnAdd->UseVisualStyleBackColor = true;
            this->btnAdd->Click += gcnew System::EventHandler(this, &AddCourseForm::btnAdd_Click);
            // 
            // btnCancel
            // 
            this->btnCancel->Location = System::Drawing::Point(441, 363);
            this->btnCancel->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->btnCancel->Name = L"btnCancel";
            this->btnCancel->Size = System::Drawing::Size(112, 35);
            this->btnCancel->TabIndex = 9;
            this->btnCancel->Text = L"Cancel";
            this->btnCancel->UseVisualStyleBackColor = true;
            this->btnCancel->Click += gcnew System::EventHandler(this, &AddCourseForm::btnCancel_Click);
            // 
            // label5
            // 
            this->label5->AutoSize = true;
            this->label5->Location = System::Drawing::Point(219, 311);
            this->label5->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
            this->label5->Name = L"label5";
            this->label5->Size = System::Drawing::Size(43, 20);
            this->label5->TabIndex = 11;
            this->label5->Text = L"Time";
            // 
            // cbDay
            // 
            this->cbDay->FormattingEnabled = true;
            this->cbDay->Items->AddRange(gcnew cli::array< System::Object^  >(7) {
                L"Monday", L"Tuesday", L"Wednesday", L"Thursday", L"Friday",
                    L"Saturday", L"Sunday"
            });
            this->cbDay->Location = System::Drawing::Point(309, 272);
            this->cbDay->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->cbDay->Name = L"cbDay";
            this->cbDay->Size = System::Drawing::Size(242, 28);
            this->cbDay->TabIndex = 7;
            // 
            // cbTime
            // 
            this->cbTime->DropDownHeight = 110;
            this->cbTime->DropDownWidth = 131;
            this->cbTime->FormattingEnabled = true;
            this->cbTime->IntegralHeight = false;
            this->cbTime->Items->AddRange(gcnew cli::array< System::Object^  >(24) {
                L"00:00", L"01:00", L"02:00", L"03:00", L"04:00",
                    L"05:00", L"06:00", L"07:00", L"08:00", L"09:00", L"10:00", L"11:00", L"12:00", L"13:00", L"14:00", L"15:00", L"16:00", L"17:00",
                    L"18:00", L"19:00", L"20:00", L"21:00", L"22:00", L"23:00"
            });
            this->cbTime->Location = System::Drawing::Point(309, 306);
            this->cbTime->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->cbTime->Name = L"cbTime";
            this->cbTime->Size = System::Drawing::Size(242, 28);
            this->cbTime->TabIndex = 10;
            // 
            // label6
            // 
            this->label6->AutoSize = true;
            this->label6->Location = System::Drawing::Point(219, 280);
            this->label6->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
            this->label6->Name = L"label6";
            this->label6->Size = System::Drawing::Size(37, 20);
            this->label6->TabIndex = 12;
            this->label6->Text = L"Day";
            // 
            // label7
            // 
            this->label7->AutoSize = true;
            this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
                static_cast<System::Byte>(0)));
            this->label7->Location = System::Drawing::Point(352, 43);
            this->label7->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
            this->label7->Name = L"label7";
            this->label7->Size = System::Drawing::Size(150, 29);
            this->label7->TabIndex = 13;
            this->label7->Text = L"Add Course";
            // 
            // AddCourseForm
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(801, 509);
            this->Controls->Add(this->label7);
            this->Controls->Add(this->label6);
            this->Controls->Add(this->label5);
            this->Controls->Add(this->btnCancel);
            this->Controls->Add(this->btnAdd);
            this->Controls->Add(this->cbRoom);
            this->Controls->Add(this->label4);
            this->Controls->Add(this->cbTeacher);
            this->Controls->Add(this->label3);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->txtName);
            this->Controls->Add(this->txtCode);
            this->Controls->Add(this->label1);
            this->Controls->Add(this->cbDay);
            this->Controls->Add(this->cbTime);
            this->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
            this->Name = L"AddCourseForm";
            this->Text = L"Add Course";
            this->Load += gcnew System::EventHandler(this, &AddCourseForm::AddCourseForm_Load);
            this->ResumeLayout(false);
            this->PerformLayout();

        }
#pragma endregion

    private:
        System::Void AddCourseForm_Load(System::Object^ sender, System::EventArgs^ e) {
            // Populate teacher and room ComboBoxes
            for each (Teacher ^ teacher in DataManager::Instance->teachers)
            {
                cbTeacher->Items->Add(teacher->name);
            }

            for each (Room ^ room in DataManager::Instance->rooms)
            {
                cbRoom->Items->Add(room->number);
            }
        }

        System::Void btnAdd_Click(System::Object^ sender, System::EventArgs^ e) {
            // Validate input
            if (String::IsNullOrEmpty(txtCode->Text) || String::IsNullOrEmpty(txtName->Text) || cbTeacher->SelectedIndex == -1 || cbRoom->SelectedIndex == -1 || String::IsNullOrEmpty(cbDay->Text) || String::IsNullOrEmpty(cbTime->Text))
            {
                MessageBox::Show("Please fill in all fields.");
                return;
            }

            String^ selectedDay = cbDay->Text;
            String^ selectedTime = cbTime->Text;

            // Create new Course object
            Teacher^ selectedTeacher = DataManager::Instance->teachers[cbTeacher->SelectedIndex];
            Room^ selectedRoom = DataManager::Instance->rooms[cbRoom->SelectedIndex];
            String^ dateTime = selectedTime + " " + selectedDay;
            Course^ newCourse = gcnew Course(txtCode->Text, txtName->Text, selectedTeacher, dateTime, selectedRoom);

            // Add new course to DataManager
            Array::Resize(DataManager::Instance->courses, DataManager::Instance->courses->Length + 1);
            DataManager::Instance->courses[DataManager::Instance->courses->Length - 1] = newCourse;

            // Write the details of the new course to a file
            String^ filePath = "course_data.txt";

            try {
                System::IO::StreamWriter^ sw = gcnew System::IO::StreamWriter(filePath, true);
                sw->WriteLine(newCourse->code + "," + newCourse->name + "," + selectedTeacher->name + "," + dateTime + "," + selectedRoom->number);
                sw->Close();
                MessageBox::Show("Course added successfully.");
            }
            catch (Exception^ ex) {
                MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
            
            this->DB->Show();
            this->Hide();
            
        }

        System::Void btnCancel_Click(System::Object^ sender, System::EventArgs^ e) {
            
            this->Hide();
            this->DB->Show();
          
        }

        System::Void txtCode_TextChanged(System::Object^ sender, System::EventArgs^ e) {
        }

        System::Void txtName_TextChanged(System::Object^ sender, System::EventArgs^ e) {
        }

        System::Void cbTeacher_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
        }

        System::Void cbRoom_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
        }
    private: System::Void dateTimePicker_ValueChanged(System::Object^ sender, System::EventArgs^ e) {
    }
};
}
