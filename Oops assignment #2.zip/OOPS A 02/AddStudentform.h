#pragma once
#include "Information.h"

namespace OOPSA02 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for AddStudentform
	/// </summary>
	public ref class AddStudentform : public System::Windows::Forms::Form
	{
	private:
		System::Windows::Forms::Form^ DB;
	public:
		AddStudentform(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		AddStudentform(System::Windows::Forms::Form^ frm)
		{
			InitializeComponent();
			DB = frm;
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~AddStudentform()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Button^ btnAddStudent;
	private: System::Windows::Forms::Button^ btnMainMenu;


	private: System::Windows::Forms::TableLayoutPanel^ tableLayoutPanel1;
	private: System::Windows::Forms::ComboBox^ cbStudentCourse;

	private: System::Windows::Forms::ComboBox^ cbStudentTeacher;

	private: System::Windows::Forms::TextBox^ tbStudentEnrollment;

	private: System::Windows::Forms::TextBox^ tbStudentName;
	private: System::Windows::Forms::ComboBox^ cbStudentSection;


	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->btnAddStudent = (gcnew System::Windows::Forms::Button());
			this->btnMainMenu = (gcnew System::Windows::Forms::Button());
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->cbStudentCourse = (gcnew System::Windows::Forms::ComboBox());
			this->cbStudentTeacher = (gcnew System::Windows::Forms::ComboBox());
			this->tbStudentName = (gcnew System::Windows::Forms::TextBox());
			this->cbStudentSection = (gcnew System::Windows::Forms::ComboBox());
			this->tbStudentEnrollment = (gcnew System::Windows::Forms::TextBox());
			this->tableLayoutPanel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(166, 20);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(257, 37);
			this->label1->TabIndex = 0;
			this->label1->Text = L"ADD STUDENT";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(44, 105);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(74, 25);
			this->label2->TabIndex = 1;
			this->label2->Text = L"NAME";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(26, 146);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(157, 25);
			this->label3->TabIndex = 2;
			this->label3->Text = L"ENROLLMENT";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(35, 186);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(109, 25);
			this->label4->TabIndex = 3;
			this->label4->Text = L"SECTION";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(35, 227);
			this->label5->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(114, 25);
			this->label5->TabIndex = 4;
			this->label5->Text = L"TEACHER";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(44, 270);
			this->label6->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(103, 25);
			this->label6->TabIndex = 5;
			this->label6->Text = L"COURSE";
			// 
			// btnAddStudent
			// 
			this->btnAddStudent->Location = System::Drawing::Point(98, 359);
			this->btnAddStudent->Margin = System::Windows::Forms::Padding(4);
			this->btnAddStudent->Name = L"btnAddStudent";
			this->btnAddStudent->Size = System::Drawing::Size(112, 28);
			this->btnAddStudent->TabIndex = 6;
			this->btnAddStudent->Text = L"ADD ";
			this->btnAddStudent->UseVisualStyleBackColor = true;
			this->btnAddStudent->Click += gcnew System::EventHandler(this, &AddStudentform::btnAddStudent_Click);
			// 
			// btnMainMenu
			// 
			this->btnMainMenu->Location = System::Drawing::Point(272, 359);
			this->btnMainMenu->Margin = System::Windows::Forms::Padding(4);
			this->btnMainMenu->Name = L"btnMainMenu";
			this->btnMainMenu->Size = System::Drawing::Size(129, 28);
			this->btnMainMenu->TabIndex = 7;
			this->btnMainMenu->Text = L"MAIN MENU";
			this->btnMainMenu->UseVisualStyleBackColor = true;
			this->btnMainMenu->Click += gcnew System::EventHandler(this, &AddStudentform::btnMainMenu_Click);
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->ColumnCount = 1;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				50)));
			this->tableLayoutPanel1->Controls->Add(this->cbStudentCourse, 0, 4);
			this->tableLayoutPanel1->Controls->Add(this->cbStudentTeacher, 0, 3);
			this->tableLayoutPanel1->Controls->Add(this->tbStudentName, 0, 0);
			this->tableLayoutPanel1->Controls->Add(this->cbStudentSection, 0, 2);
			this->tableLayoutPanel1->Controls->Add(this->tbStudentEnrollment, 0, 1);
			this->tableLayoutPanel1->Location = System::Drawing::Point(154, 101);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->RowCount = 5;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 56.33803F)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 43.66197F)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 41)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 36)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 36)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(200, 185);
			this->tableLayoutPanel1->TabIndex = 8;
			// 
			// cbStudentCourse
			// 
			this->cbStudentCourse->FormattingEnabled = true;
			this->cbStudentCourse->Location = System::Drawing::Point(3, 151);
			this->cbStudentCourse->Name = L"cbStudentCourse";
			this->cbStudentCourse->Size = System::Drawing::Size(194, 33);
			this->cbStudentCourse->TabIndex = 4;
			// 
			// cbStudentTeacher
			// 
			this->cbStudentTeacher->FormattingEnabled = true;
			this->cbStudentTeacher->Location = System::Drawing::Point(3, 115);
			this->cbStudentTeacher->Name = L"cbStudentTeacher";
			this->cbStudentTeacher->Size = System::Drawing::Size(194, 33);
			this->cbStudentTeacher->TabIndex = 3;
			// 
			// tbStudentName
			// 
			this->tbStudentName->Location = System::Drawing::Point(3, 3);
			this->tbStudentName->Multiline = true;
			this->tbStudentName->Name = L"tbStudentName";
			this->tbStudentName->Size = System::Drawing::Size(194, 20);
			this->tbStudentName->TabIndex = 0;
			this->tbStudentName->TextChanged += gcnew System::EventHandler(this, &AddStudentform::tbStudentName_TextChanged);
			// 
			// cbStudentSection
			// 
			this->cbStudentSection->FormattingEnabled = true;
			this->cbStudentSection->Location = System::Drawing::Point(3, 74);
			this->cbStudentSection->Name = L"cbStudentSection";
			this->cbStudentSection->Size = System::Drawing::Size(194, 33);
			this->cbStudentSection->TabIndex = 2;
			// 
			// tbStudentEnrollment
			// 
			this->tbStudentEnrollment->Location = System::Drawing::Point(3, 43);
			this->tbStudentEnrollment->Name = L"tbStudentEnrollment";
			this->tbStudentEnrollment->Size = System::Drawing::Size(194, 30);
			this->tbStudentEnrollment->TabIndex = 1;
			// 
			// AddStudentform
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(13, 25);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(465, 484);
			this->Controls->Add(this->tableLayoutPanel1);
			this->Controls->Add(this->btnMainMenu);
			this->Controls->Add(this->btnAddStudent);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"AddStudentform";
			this->Text = L"AddStudentform";
			this->tableLayoutPanel1->ResumeLayout(false);
			this->tableLayoutPanel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}

#pragma endregion
	private: System::Void tbStudentName_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void btnAddStudent_Click(System::Object^ sender, System::EventArgs^ e) {
	// Get the DataManager instance
	DataManager^ dataManager = DataManager::Instance;

	// Retrieve values from the textboxes and combo boxes
	String^ name = tbStudentName->Text;
	String^ enrollment = tbStudentEnrollment->Text;
	String^ section = cbStudentSection->SelectedItem->ToString();
	String^ teacher = cbStudentTeacher->SelectedItem->ToString();
	String^ course = cbStudentCourse->SelectedItem->ToString();

	
	Teacher^ selectedTeacher = nullptr;
	for each (Teacher ^ t in dataManager->teachers) {
		if (t->name == teacher) {
			selectedTeacher = t;
			break;
		}
	}

	Course^ selectedCourse = nullptr;
	for each (Course ^ c in dataManager->courses) {
		if (c->name == course) {
			selectedCourse = c;
			break;
		}
	}

	
	if (selectedTeacher == nullptr || selectedCourse == nullptr) {
		MessageBox::Show("Error: Selected teacher or course not found!");
		return;
	}

	Student^ newStudent = gcnew Student(name, enrollment, section);

	
	MessageBox::Show("Student added successfully!");
}

private: System::Void btnMainMenu_Click(System::Object^ sender, System::EventArgs^ e) {

	this->DB->Show();
	this->Hide();
}
};
}
