#pragma once
#include"Information.h"
namespace OOPSA02 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for SearchByDay
	/// </summary>
	public ref class SearchByDay : public System::Windows::Forms::Form
	{
	private:
		System::Windows::Forms::Form^ DB;

	public:
		SearchByDay(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		SearchByDay(System::Windows::Forms::Form^ frm)
		{
			InitializeComponent();
			DB = frm;
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~SearchByDay()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	protected:
	private: System::Windows::Forms::ComboBox^ cbDay;
	private: System::Windows::Forms::Button^ btnSearch;
	private: System::Windows::Forms::Button^ btnGoBack;
	private: System::Windows::Forms::Label^ label1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->cbDay = (gcnew System::Windows::Forms::ComboBox());
			this->btnSearch = (gcnew System::Windows::Forms::Button());
			this->btnGoBack = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(54, 358);
			this->dataGridView1->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersWidth = 62;
			this->dataGridView1->Size = System::Drawing::Size(744, 378);
			this->dataGridView1->TabIndex = 8;
			// 
			// cbDay
			// 
			this->cbDay->FormattingEnabled = true;
			this->cbDay->Items->AddRange(gcnew cli::array< System::Object^  >(7) {
				L"Monday", L"Tuesday", L"Wednesday", L"Thursday", L"Friday",
					L"Saturday", L"Sunday"
			});
			this->cbDay->Location = System::Drawing::Point(222, 198);
			this->cbDay->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->cbDay->Name = L"cbDay";
			this->cbDay->Size = System::Drawing::Size(380, 28);
			this->cbDay->TabIndex = 9;
			// 
			// btnSearch
			// 
			this->btnSearch->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnSearch->Location = System::Drawing::Point(222, 275);
			this->btnSearch->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->btnSearch->Name = L"btnSearch";
			this->btnSearch->Size = System::Drawing::Size(180, 51);
			this->btnSearch->TabIndex = 10;
			this->btnSearch->Text = L"Search";
			this->btnSearch->UseVisualStyleBackColor = true;
			this->btnSearch->Click += gcnew System::EventHandler(this, &SearchByDay::btnSearch_Click);
			// 
			// btnGoBack
			// 
			this->btnGoBack->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnGoBack->Location = System::Drawing::Point(424, 275);
			this->btnGoBack->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->btnGoBack->Name = L"btnGoBack";
			this->btnGoBack->Size = System::Drawing::Size(180, 51);
			this->btnGoBack->TabIndex = 11;
			this->btnGoBack->Text = L"Go Back";
			this->btnGoBack->UseVisualStyleBackColor = true;
			this->btnGoBack->Click += gcnew System::EventHandler(this, &SearchByDay::btnGoBack_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(230, 78);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(353, 55);
			this->label1->TabIndex = 12;
			this->label1->Text = L"Search by Day";
			// 
			// SearchByDay
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(842, 786);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnGoBack);
			this->Controls->Add(this->btnSearch);
			this->Controls->Add(this->cbDay);
			this->Controls->Add(this->dataGridView1);
			this->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->Name = L"SearchByDay";
			this->Text = L"SearchByDay";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnSearch_Click(System::Object^ sender, System::EventArgs^ e) {

		// Clear existing rows and columns in the data grid view
		dataGridView1->Rows->Clear();
		dataGridView1->Columns->Clear();

		// Add columns to the data grid view
		dataGridView1->Columns->Add("CourseName", "Course Name");
		dataGridView1->Columns->Add("CourseTime", "Course Time");
		dataGridView1->Columns->Add("TeacherName", "Teacher Name");

		// Get the selected day from the combo box
		String^ selectedDay = cbDay->Text;

		// Iterate through the list of courses
		for each (Course ^ course in DataManager::Instance->courses) {
			// Check if the course is scheduled on the selected day
			if (course->time->Contains(selectedDay)) {
				// Add the course details to the data grid view
				DataGridViewRow^ row = gcnew DataGridViewRow();
				row->CreateCells(dataGridView1);
				row->SetValues(course->name, course->time, course->teacher->name);
				dataGridView1->Rows->Add(row);
			}
		}
	}

private: System::Void btnGoBack_Click(System::Object^ sender, System::EventArgs^ e) {

	this->DB->Show();
	this->Hide();
}
};
}
